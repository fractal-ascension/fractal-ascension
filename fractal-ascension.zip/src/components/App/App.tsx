import React, { useEffect } from 'react';
import { useAppDispatch } from "../../store";
import { saveCharacter } from '../Character/characterSlice';
import { saveInventory } from '../Inventory/inventorySlice';
import Main from "../Main/main";
import Footer from "../Footer/footer";
import "./App.scss";

const App: React.FC = () => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    const intervalId = setInterval(() => {
      dispatch(saveCharacter());
      dispatch(saveInventory());
    }, 300000); // 300,000 milliseconds = 5 minutes

    return () => clearInterval(intervalId);
  }, [dispatch]);

  return (
    <>
      <div className="app">
        <Main></Main>
        <Footer></Footer>
      </div>
    </>
  );
}

export default App;
